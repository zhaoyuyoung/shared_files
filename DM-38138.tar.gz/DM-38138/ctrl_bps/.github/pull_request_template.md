## Checklist

- [ ] ran Jenkins
- [ ] added a release note for user-visible changes to `doc/changes`
